<h2>Home</h2>

<div class="info">Selamat datang, <strong>Suendri</strong></div>